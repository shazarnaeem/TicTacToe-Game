package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private boolean playerXTurn = true;
    private final int[][] board = new int[3][3];
    private final Button[] buttons = new Button[9];
    private TextView statusTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusTextView = findViewById(R.id.status);
        Button resetButton = findViewById(R.id.resetButton);
        GridLayout gridLayout = findViewById(R.id.gridLayout);

        for (int i = 0; i < gridLayout.getChildCount(); i++) {
            buttons[i] = (Button) gridLayout.getChildAt(i);
            buttons[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    buttonClick((Button) v);
                }
            });
        }

        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetGame();
            }
        });

        resetGame();
    }

    @SuppressLint("SetTextI18n")
    private void buttonClick(Button button) {
        int index = Integer.parseInt(button.getTag().toString());

        if (board[index / 3][index % 3] != 0) {
            return;
        }

        board[index / 3][index % 3] = playerXTurn ? 1 : 2;
        button.setText(playerXTurn ? "X" : "O");

        if (checkWin()) {
            statusTextView.setText("Player " + (playerXTurn ? "X" : "O") + " Wins!");
            disableButtons();
        } else if (isBoardFull()) {
            statusTextView.setText("It's a Draw!");
        } else {
            playerXTurn = !playerXTurn;
            statusTextView.setText("Player " + (playerXTurn ? "X" : "O") + "'s Turn");
        }
    }

    private boolean checkWin() {
        for (int i = 0; i < 3; i++) {
            if (board[i][0] != 0 && board[i][0] == board[i][1] && board[i][0] == board[i][2]) {
                return true;
            }
            if (board[0][i] != 0 && board[0][i] == board[1][i] && board[0][i] == board[2][i]) {
                return true;
            }
        }
        if (board[0][0] != 0 && board[0][0] == board[1][1] && board[0][0] == board[2][2]) {
            return true;
        }
        return board[0][2] != 0 && board[0][2] == board[1][1] && board[0][2] == board[2][0];
    }

    private boolean isBoardFull() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board[i][j] == 0) {
                    return false;
                }
            }
        }
        return true;
    }

    private void disableButtons() {
        for (Button button : buttons) {
            button.setEnabled(false);
        }
    }

    @SuppressLint("SetTextI18n")
    private void resetGame() {
        playerXTurn = true;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                board[i][j] = 0;
            }
        }
        for (Button button : buttons) {
            button.setText("");
            button.setEnabled(true);
        }
        statusTextView.setText("Player X's Turn");
    }
}
